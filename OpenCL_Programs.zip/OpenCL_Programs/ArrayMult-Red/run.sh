#!/bin/bash
for glob in 1024 7168 15360 71680 102400 204800 2048000 6144000
do
    for loc in 32 64 96 128 256 512 
    do
    g++ -DNMB=$glob -DLOCAL_SIZE=$loc -o first first.cpp /scratch/cuda-7.0/lib64/libOpenCL.so -lm -fopenmp && ./first | tee -a out3.txt
    done
done
