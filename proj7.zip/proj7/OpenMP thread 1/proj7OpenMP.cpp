#include<stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#include<fstream>
#include<iostream>

#ifndef NUMT
#define NUMT	1
#endif

#define NUMTRIES    40

int
main( )
{

#ifndef _OPENMP
        fprintf( stderr, "OpenMP is not supported here -- sorry.\n" );
        return 1;
#endif

omp_set_num_threads( NUMT );
fprintf( stderr, "Using %d threads\n", NUMT );


FILE *fp;
int Size;
float *Array;
float *Sums;
int i;

fp = fopen( "signal.txt", "r" );
if( fp == NULL )
{
	fprintf( stderr, "Cannot open file 'signal.txt'\n" );
	exit( 1 );
}
fscanf( fp, "%d", &Size );
Array = (float *)malloc( 2 * Size * sizeof(float) );
Sums  = (float *)malloc( 1 * Size * sizeof(float) );
for( i = 0; i < Size; i++ )
{
	fscanf( fp, "%f", &Array[i] );
	Array[i+Size] = Array[i];		// duplicate the array
}
fclose( fp );

double time0 = omp_get_wtime( );
   
#pragma omp parallel for
for( int shift = 0; shift < Size+1; shift++ )
{
	float sum = 0.;
	for( int i = 0; i < Size; i++ )
	{
		sum += Array[i] * Array[i + shift];
	}
	Sums[shift] = sum;	// note the "fix #2" from false sharing if you are using OpenMP
    //printf("Shift = %d  sum = %8.2lf\n", shift, sum);
    std::ofstream file;
	file.open("proj7openMP.txt", std::ios_base::app);
	file << shift << " "
		 << sum << "\n";
	file.close();
}
double time1 = omp_get_wtime( );
double megaMults = (double)Size/(time1-time0)/1000.;

printf( "Peak Performance = %lf KiloMults/Sec\n", megaMults );

return 0;
}
