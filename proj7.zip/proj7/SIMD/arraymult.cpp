#include <stdio.h>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <math.h>
#include <omp.h>
#include "simd.p7.h"
#include <ctime>
#include <sys/time.h>
#include <sys/resource.h>

int main( int argc, char *argv[ ] )
{
   #ifndef _OPENMP
    fprintf( stderr, "No OpenMP support!\n" );
    return 1;
    #endif


    FILE *fp = fopen( "signal.txt", "r" );
    if( fp == NULL )
    {
        fprintf( stderr, "Cannot open file 'signal.txt'\n" );
        exit( 1 );
    }
    int Size;
    fscanf( fp, "%d", &Size );
    float *Array = new float[ 2*Size ];
    float *Sums  = new float[ 1*Size ];
    for( int i = 0; i < Size; i++ )
    {
        fscanf( fp, "%f", &Array[i] );
        Array[i+Size] = Array[i];       // duplicate the array
    }
    fclose( fp );
    double time0 = omp_get_wtime();
    for( int shift = 0; shift < Size; shift++ )
    {
        float sum = 0.;
        Sums[shift] = SimdMulSum( &Array[0], &Array[0+shift], Size );
        //printf("Shift = %d  sum = %8.2lf\n", shift, Sums[shift]);
        // printf("%d", Size);
        
    }
    double time1 = omp_get_wtime( );
    double megaMults = (double)Size/(time1-time0)/1000.;
    printf( "Peak Performance = %lf KiloMults/Sec\n", megaMults );
    return 0;
}